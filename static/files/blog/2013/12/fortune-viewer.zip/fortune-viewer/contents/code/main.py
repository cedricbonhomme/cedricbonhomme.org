# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyKDE4.plasma import Plasma
from PyKDE4 import plasmascript
import subprocess

class FortuneViewer(plasmascript.Applet):
    def __init__(self,parent,args=None):
        plasmascript.Applet.__init__(self,parent)

    def init(self):
        timer = QTimer(self);
        self.setHasConfigurationInterface(False)

        self.theme = Plasma.Svg(self)
        self.theme.setImagePath("widgets/background")
        self.setBackgroundHints(Plasma.Applet.DefaultBackground)

        self.layout = QGraphicsLinearLayout(Qt.Horizontal, self.applet)
        self.logMessage = Plasma.Label(self.applet)
        self.layout.addItem(self.logMessage)
        self.setLayout(self.layout)
        self.resize(400, 400)
        QObject.connect(timer, SIGNAL("timeout()"), self.fortuneUpdate)
        timer.start(5000)
        self.fortuneUpdate()

    def fortuneUpdate(self):
        p=subprocess.Popen("/usr/games/fortune", shell=True, \
            stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        output,errors=p.communicate()
        self.logMessage.setText(output+errors)

def CreateApplet(parent):
    return FortuneViewer(parent)