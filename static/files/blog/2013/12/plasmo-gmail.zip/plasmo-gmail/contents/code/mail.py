#!/usr/bin/python

# libgmailatom 2.0

from xml.dom.minidom import parseString
import urllib2

class GmailAtom2Exception(Exception):
	pass

class Mail:
	def __init__(self):
		self.authors = []

	def __eq__(a, b):
		return a.uid==b.uid

	def __ne__(a, b):
		return not a==b

	def __lt__(a, b):
		return a.date<b.date or (a.date==b.date and a.authors<b.authors) or (a.date==b.date and a.authors==b.authors and a.uid<b.uid)

	def __le__(a, b):
		return a<b or a==b

	def __gt__(a, b):
		return a.date>b.date or (a.date==b.date and a.authors>b.authors) or (a.date==b.date and a.authors==b.authors and a.uid>b.uid)

	def __ge__(a, b):
		return a>b or a==b

class Author:
	def __eq__(a, b):
		return a.name==b.name and a.email==b.email

	def __ne__(a, b):
		return not a==b

	def __lt__(a, b):
		return a.name<b.name or (a.name==b.name and a.email<b.email)

	def __le__(a, b):
		return a<b or a==b

	def __gt__(a, b):
		return a.name>b.name or (a.name==b.name and a.email>b.email)

	def __ge__(a, b):
		return a>b or a==b

class GmailAtom2:
	def __init__(self, username, password, protocol="https", host="mail.google.com", path="/mail/feed/atom", proxy=None):
		realm = "New mail feed"
		self.url = protocol + "://" + host + path
		self.path = path
		self.unreadMail = []

		auth_handler = urllib2.HTTPBasicAuthHandler()
		auth_handler.add_password( realm, protocol+"://"+host, username, password)

		if proxy != None:
			proxy_handler = urllib2.ProxyHandler({protocol: proxy})
			self.opener = urllib2.build_opener(auth_handler, proxy_handler)
		else:
			self.opener = urllib2.build_opener(auth_handler)

	def _getUrl(self):
		return self.opener.open(self.url).read()

	def _getPropertyValue(self, node, propertyName):
		text = ""

		pptyNode = node.getElementsByTagName(propertyName).item(0)

		if pptyNode==None:
			raise GmailAtom2Exception, "Invalid feed format. Property '%s' not found in element '%s'." % (propertyName, node.tagName)

		for child in pptyNode.childNodes:
			text = text + child.nodeValue

		text = text.strip()

		return text

	def _getAuthorFromNode(self, node):
		a = Author()
		a.name = self._getPropertyValue(node, "name")
		a.email = self._getPropertyValue(node, "email")

		return a

	def _getMailFromNode(self, node):
		m = Mail()
		m.uid = self._getPropertyValue(node, "id")
		m.subject = self._getPropertyValue(node, "title")
		m.summary = self._getPropertyValue(node, "summary")
		m.date = self._getPropertyValue(node, "issued")

		authorNode = node.getElementsByTagName("author").item(0)
		if authorNode == None:
			raise GmailAtom2Exception, "Invalid feed Format. Author not found in entry."

		m.authors.append(self._getAuthorFromNode(authorNode))

		for contributor in node.getElementsByTagName("contributor"):
			m.authors.append(self._getAuthorFromNode(contributor))

		m.authors.reverse()

		return m

	def checkMail(self):
		# raises URLError
		xmlString = self._getUrl()

		try:
			xmlDom = parseString(xmlString)
		except:
			raise GmailAtom2Exception, "Unable to parse feed XML."

		if xmlDom.firstChild.tagName != "feed":
			raise GmailAtom2Exception, "Invalid feed format. <%s> found as root element."%(xmlDom.firstChild.tagName)

		unreadMail = []

		entries = xmlDom.getElementsByTagName("entry")
		for entry in entries:
			unreadMail.append(self._getMailFromNode(entry))

		xmlDom.unlink()

		self.unreadMail = unreadMail


if __name__ == '__main__':
    mail = GmailAtom2('', '')
    mail.checkMail()