# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyKDE4.plasma import Plasma
from PyKDE4 import plasmascript
import subprocess
import os

import mail
import ConfigParser

class MailViewer(plasmascript.Applet):
    def __init__(self,parent,args=None):
        plasmascript.Applet.__init__(self,parent)
        os.chdir("./plasmo-gmail/contents/code/")
        config = ConfigParser.RawConfigParser()
        config.read("./plasmo-gmail.cfg")
        self.username = config.get('global','username')
        self.password = config.get('global','password')

    def init(self):
        timer = QTimer(self);
        self.setHasConfigurationInterface(False)

        self.theme = Plasma.Svg(self)
        self.theme.setImagePath("widgets/background")
        self.setBackgroundHints(Plasma.Applet.DefaultBackground)

        self.layout = QGraphicsLinearLayout(Qt.Horizontal, self.applet)
        self.logMessage = Plasma.Label(self.applet)
        self.layout.addItem(self.logMessage)
        self.setLayout(self.layout)
        self.resize(200, 200)
        QObject.connect(timer, SIGNAL("timeout()"), self.update)
        timer.start(10000)
        self.update()

    def update(self):
        output = ""
        gmail = mail.GmailAtom2(self.username, self.password)
        gmail.checkMail()
        if gmail.unreadMail:
            for a_mail in gmail.unreadMail:
                output = a_mail.subject + " " + a_mail.date + "\n"
                output += "\n\t" + a_mail.summary + "\n"
        else:
            output = "No new mail !"

        self.logMessage.setText(output)

def CreateApplet(parent):
    return MailViewer(parent)