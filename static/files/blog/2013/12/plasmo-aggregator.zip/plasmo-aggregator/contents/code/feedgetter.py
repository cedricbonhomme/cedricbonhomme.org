#! /usr/local/bin/python
#-*- coding: utf-8 -*-

"""feed_getter

License of feed_getter :
http://www.gnu.org/licenses/gpl.html

thanks to :
http://www.feedparser.org/ by Mark Pilgrim
"""

__author__ = "Cedric Bonhomme"
__version__ = "$Revision: 0.1 $"
__date__ = "$Date: 2009/04/01 $"
__copyright__ = "Copyright (c) 2009 Cedric Bonhomme"
__license__ = "GPL"

import re
import threading
import feedparser


url_finders = [ \
    re.compile("([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}|(((news|telnet|nttp|file|http|ftp|https)://)|(www|ftp)[-A-Za-z0-9]*\\.)[-A-Za-z0-9\\.]+)(:[0-9]*)?/[-A-Za-z0-9_\\$\\.\\+\\!\\*\\(\\),;:@&=\\?/~\\#\\%]*[^]'\\.}>\\),\\\"]"), \
    re.compile("([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}|(((news|telnet|nttp|file|http|ftp|https)://)|(www|ftp)[-A-Za-z0-9]*\\.)[-A-Za-z0-9\\.]+)(:[0-9]*)?"), \
    re.compile("(~/|/|\\./)([-A-Za-z0-9_\\$\\.\\+\\!\\*\\(\\),;:@&=\\?/~\\#\\%]|\\\\)+"), \
    re.compile("'\\<((mailto:)|)[-A-Za-z0-9\\.]+@[-A-Za-z0-9\\.]+"), \
]

feeds_list = []
list_of_threads = []

def process(the_good_url):
    """Request the URL

    Executed in a thread.
    """
    feeds_list.append(feedparser.parse(the_good_url))

def get_feed_info():
    """Launch the threads

    Parse the file 'feeds.lst' and launch a thread for each RSS feeds.
    """
    for a_feed in feeds_file.readlines():
        for url_regexp in url_finders:
            if url_regexp.match(a_feed):
                the_good_url = url_regexp.match(a_feed).group(0).replace("\n", "")
                try:
                    thread = threading.Thread(None, process, \
                                        None, (the_good_url,))
                    thread.start()
                    list_of_threads.append(thread)
                except:
                    pass
                break
    for th in list_of_threads:
        th.join()


def write_info():
    """Print or write in a file the result."""
    if options.output != "":
        html_head = '<html>\n<header>\n\t<title>Feed Getter</title>' + \
                    '\n</header>\n<body>\n'
        html_foot = '\n</body>\n</html>'
        html = html_head

    for a_feed in feeds_list:

        if options.output == "":
            title = a_feed.feed.title.encode('utf-8')
            print "-"* len(title)
            print title
        else:
            html += '\t<h2>Feed : ' + a_feed.feed.title + '</h2>\n'
            html += '\t\t<ul>\n'

        for i in a_feed['entries']:

            if options.output == "":
                print "\t" + i.title.encode('utf-8')
                print "\t\t" + i.link.encode('utf-8')

            else:
                html += '\t\t\t<li>' + i.title + '<br />\n'
                html += '\t\t\t<a href="' + i.link + '">Entire article</a>' + \
                        '\n\t\t\t</li>\n'

        if options.output == "":
            print
        else:
            html += '\t\t</ul>'

    if options.output != "":
        html += html_foot
        html_file = open(options.output, "w")
        html_file.write(html.encode("utf-8"))
        html_file.close()


if __name__ == "__main__":
    # Point of entry in execution mode
    try:
        feeds_file = open("./feed.lst")
    except:
        print "./feed.lst not found"
        exit(0)
    from optparse import OptionParser

    parser = OptionParser()
    parser.add_option("-o", "--output", dest="output",
                    help="output, expect a file name (*.html)")
    parser.set_defaults(output = "")

    (options, args) = parser.parse_args()

    get_feed_info()
    write_info()
